#include "hashtable.c"

int main()
{
    run();
}
